----------For q1.sh------------
Input: Relative or Absolute path of any file
Output: middle line in the file mentioned

command: bash ./q1.sh

----------For q2.sh------------
command: bash ./q2.sh
